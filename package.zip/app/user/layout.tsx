import UserSidebar from "@/components/user/user-sidebar";
import MobileSidebar from "@/components/user/mobile-sidebar";

export default function UserLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="admin-bg min-h-screen w-full flex">
      <div className="hidden lg:block h-screen sticky top-0">
        <UserSidebar />
      </div>
      <MobileSidebar />
      <main className="flex-1 min-h-screen p-4 lg:p-8 overflow-hidden">
        {children}
      </main>
    </div>
  );
}