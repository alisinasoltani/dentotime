import React from 'react'

const page = () => {
  return (
    <div>Doctors Mange Page</div>
  )
}

export default page