export default function AdminDashboardPage() {
  return (
    <div className="w-full h-full flex items-center justify-center">
      {/* صفحه اصلی پنل ادمین - محتوایی ندارد به جز سایدبار */}
    </div>
  );
}