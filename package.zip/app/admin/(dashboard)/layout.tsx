import AdminSidebar from "@/components/admin/admin-sidebar";
import MobileSidebar from "@/components/admin/mobile-sidebar";

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="admin-bg min-h-screen w-full flex">
      {/* Desktop Sidebar - Fixed */}
      <div className="hidden lg:block h-screen sticky top-0">
        <AdminSidebar />
      </div>

      {/* Mobile Sidebar Trigger */}
      <MobileSidebar />

      {/* Main Content Area */}
      <main className="flex-1 min-h-screen p-4 lg:p-8">
        {children}
      </main>
    </div>
  );
}