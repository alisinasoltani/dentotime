// =============================================================================
// lib/api.ts
// Axios instance + interceptors (Section 3.1).
// =============================================================================

import axios, {
  type AxiosError,
  type InternalAxiosRequestConfig,
} from 'axios';
import {
  getAccessToken,
  getRefreshToken,
  setTokens,
  clearTokens,
} from './auth';
import { API_BASE_URL } from './config';

const api = axios.create({
  baseURL: `${API_BASE_URL}/api/v1`,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 0, // No global timeout for large chat attachments (Section 7.5)
});

api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = getAccessToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error),
);

type RetryableConfig = InternalAxiosRequestConfig & { _retry?: boolean };

let isRefreshing = false;
let failedQueue: Array<{
  resolve: (token: string) => void;
  reject: (error: unknown) => void;
}> = [];

function processQueue(error: unknown, token: string | null): void {
  failedQueue.forEach(({ resolve, reject }) => {
    if (error) {
      reject(error);
    } else if (token) {
      resolve(token);
    }
  });
  failedQueue = [];
}

function getLoginPath(): string {
  if (typeof window === 'undefined') return '/login';
  return window.location.pathname.startsWith('/admin') ? '/admin/login' : '/login';
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    // اگر خطا 401 است و این اولین تلاش برای این درخواست است
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      const refreshToken = localStorage.getItem("refresh_token");
      
      // 🚨 نکته کلیدی: اگر اصلاً رفرش توکنی در حافظه نیست، یعنی کاربر لاگین نکرده است
      // پس نباید او را به صفحه لاگین هدایت کنیم (مخصوصاً در صفحه اصلی سایت)
      if (!refreshToken) {
        return Promise.reject(error); // فقط ارور را برمی‌گردانیم
      }

      try {
        const res = await axios.post("/api/v1/auth/token/refresh/", {
          refresh: refreshToken,
        });
        localStorage.setItem("access_token", res.data.access);
        api.defaults.headers.common.Authorization = `Bearer ${res.data.access}`;
        return api(originalRequest);
      } catch (err) {
        // اگر توکن وجود داشت اما منقضی شده بود، آن را پاک می‌کنیم
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        
        // کاربر را فقط در صورتی به لاگین هدایت کن که در مسیر پنل ادمین باشد
        if (typeof window !== "undefined" && window.location.pathname.startsWith("/admin")) {
          window.location.href = "/admin/login";
        }
        return Promise.reject(err);
      }
    }
    return Promise.reject(error);
  }
);

export default api;